
from dealer.excel_deal import ExcelSaver
from dealer.path_deal import PathReader
from dealer.word_dealer import WordDealer

if __name__ == '__main__':
    pr = PathReader()

    es = ExcelSaver()

    for word_path in pr.get_word_path():
        #print(word_path) #docs_with_keyword\内蒙古管局\5中国移动内蒙古公司自治区政务云安全平台搭建.docx
        key_word = pr.get_key_word()  # 因为本业务中关键字是从文件夹的名字里面读取的来的，所以是PathReader的方法得到
        file_name = pr.get_file_name()
        #print(key_word,file_name) #内蒙古管局 5中国移动内蒙古公司自治区政务云安全平台搭建.docx
        wd = WordDealer(word_path, key_word)

        sheet_data=wd.read_word(word_path,key_word)
        #print(sheet_data)
        #completion_year, province, para = wd.extract_paragraph()
        #print(completion_year)
        # print(completion_year, province, para)
        # print()
        #es.add_row(file_name, sheet_data)  # 目前excel格式也是固定的
        es.add_row(sheet_data)
    es.save_xlsx()

    print('所有文件均已处理完毕')
