KEY_FOLDS_PATH = r'..\..\docs_with_keyword\已清洗数据\各省管局'
