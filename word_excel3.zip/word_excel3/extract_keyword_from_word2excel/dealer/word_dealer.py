import os
import time

from win32com import client as wc
from retry import retry
from docx import Document


class WordDealer(object):
    def __init__(self, doc_path, key_word):
        self.doc_path = doc_path
        self.is_doc = False
        if '管局' in key_word:
            self.key_word = key_word.split('第')[0]
            #print(self.key_word)
        else:
            self.key_word = key_word
        if doc_path.endswith('.doc') and not doc_path.startswith('~$'):
            self.is_doc = True
            print('当前文件为doc格式，正在转换为docx格式用于处理', doc_path)
            self.doc2docx()
            self.str2date()

    def read_word(self,doc_path,key_word):
        word = Document(doc_path)  # 读入文件
        print(doc_path)
        tables = word.tables
        # print(tables)
        tb = tables[0]
        # 获取表格的行
        tb_rows = tb.rows
        # print(len(tb_rows))
        tb_row_data = []
        for i in range(len(tb_rows)):
            row_data = []
            row_cells = tb_rows[i].cells
            # 读取每一行单元格内容
            for cell in row_cells:
                row_data.append(cell.text)  # 单元格内容
            # print(row_data)  # 打印整行数据
            tb_row_data.append(row_data)
            #print(tb_row_data)

        #std_data=[]
        for i in range(len(tb_row_data)):
            tb_row_data[i] = sorted(set(tb_row_data[i]), key=tb_row_data[i].index)
        for i in range(len(tb_row_data)):
            while len(tb_row_data[i]) < 4:
                tb_row_data[i].append('/')
        # if len(tb_row_data[0])==4:
        #     for i in range(len(tb_row_data)):
        #         tb_row_data[i].append(tb_row_data[i][3])
        if '联合申报单位' not in tb_row_data[9][0]:
            tb_row_data.insert(9, ['联合申报单位', '/', '/', '/'])
        if '联合申报单位' not in tb_row_data[10][0]:
            tb_row_data.insert(10, ['联合申报单位', '/', '/', '/'])
        #标准化补齐’/‘
        for i in range(len(tb_row_data)):
            j = 0
            for item in tb_row_data[i]:
                j += 1
                if item == '':
                    tb_row_data[i][j - 1] = '/'

        tb_row_data[2][3]=self.str2date(tb_row_data[2][3])

        sheet_data = key_word,tb_row_data[13][1], tb_row_data[1][1], tb_row_data[2][1], tb_row_data[2][3], \
                     tb_row_data[3][1], tb_row_data[3][3], tb_row_data[4][1], tb_row_data[4][3], \
                     tb_row_data[5][1], tb_row_data[5][3], tb_row_data[6][1], tb_row_data[6][3], \
                     tb_row_data[7][1], tb_row_data[9][1], tb_row_data[9][2], tb_row_data[9][3], \
                     tb_row_data[10][1], tb_row_data[10][2], tb_row_data[10][3], tb_row_data[14][1], \
                     tb_row_data[15][1], tb_row_data[16][1], tb_row_data[16][3], tb_row_data[17][1], \
                     tb_row_data[18][1], tb_row_data[19][1], tb_row_data[20][1], tb_row_data[20][3]
        #tb_row_data[16][4]职务职称，tb_row_data[20][4]平台用户\n类型

        # print(len(sheet_data))
        # print(type(sheet_data))
        return sheet_data

    @retry(tries=10)
    def doc2docx(self):
        word = wc.Dispatch('Word.Application')

        doc = word.Documents.Open(os.path.abspath(self.doc_path))  # 目标路径下的文件
        self.doc_path += 'x'
        doc.SaveAs((os.path.abspath(self.doc_path)), 12, False, "", True, "", False, False, False,
                   False)  # 转化后路径下的文件
        doc.Close()
        word.Quit()
        os.remove(os.path.abspath(self.doc_path))
        print('.doc转换完成', self.doc_path)
        time.sleep(0.5)

    #统一标准化”成立时间“
    def str2date(self,str_date):
        str_date = str_date.strip()
        year = 1900
        month = 1
        day = 1
        if (len(str_date) > 11):
            str_date = str_date[:11]
        if (str_date.find('-') > 0):
            year = str_date[:4]
            if (year.isdigit()):
                year = int(year)
            else:
                year = 0
            month = str_date[5:str_date.rfind('-')]
            if (month.isdigit()):
                month = int(month)
            else:
                month = 0
            if (str_date.find(' ') == -1):
                day = str_date[str_date.rfind('-') + 1:]
            else:
                day = str_date[str_date.rfind('-') + 1:str_date.find(' ')]
            if (day.isdigit()):
                day = int(day)
            else:
                day = 0
        elif (str_date.find('年') > 0):
            year = str_date[:4]
            if (year.isdigit()):
                year = int(year)
            else:
                year = 0
            month = str_date[5:str_date.rfind('月')]
            if (month.isdigit()):
                month = int(month)
            else:
                month = 0
            # print(str_date.rfind('月'))
            if str_date.rfind(('月')):
                day = str_date[str_date.rfind('月') + 1:str_date.rfind('日')]
                if (day.isdigit()):
                    day = int(day)
                else:
                    day = 0
            if str_date.rfind(('月')) == -1:
                day = 0
        elif (str_date.find('/') > 0):
            year = str_date[:4]
            if (year.isdigit()):
                year = int(year)
            else:
                year = 0
            month = str_date[5:str_date.rfind('/')]
            if (month.isdigit()):
                month = int(month)
            else:
                month = 0
            if (str_date.find(' ') == -1):
                day = str_date[str_date.rfind('/') + 1:]
            else:
                day = str_date[str_date.rfind('/') + 1:str_date.find(' ')]
            if (day.isdigit()):
                day = int(day)
            else:
                day = 0
        elif (str_date.find('.') > 0):
            year = str_date[:4]
            if (year.isdigit()):
                year = int(year)
            else:
                year = 0
            month = str_date[5:str_date.rfind('.')]
            if (month.isdigit()):
                month = int(month)
            else:
                month = 0
            if (str_date.find(' ') == -1):
                day = str_date[str_date.rfind('.') + 1:]
            else:
                day = str_date[str_date.rfind('.') + 1:str_date.find(' ')]
            if (day.isdigit()):
                day = int(day)
            else:
                day = 0
        elif str_date.isdigit():
            year = str_date
            month = 0
            day = 0
        else:
            year = 8888
            month = 88
            day = 88
        if month < 10:
            month = '0' + str(month)
        if day < 10:
            day = '0' + str(day)
        return '%s年%s月%s日' % (year, month, day)