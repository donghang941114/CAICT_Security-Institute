import xlsxwriter


class ExcelSaver(object):
    def __init__(self):
        self.f = xlsxwriter.Workbook(f'项目信息汇总表.xlsx')
        self.worksheet1 = self.f.add_worksheet('sheet1')  # 只用一个sheet
        self.worksheet1.write_row("A1", ['推荐项目单位','项目名称','牵头申报单位','组织机构代码/三证合一码',
                                         '成立时间','通讯地址','注册资本（万元）','联系人',
                                         '联系电话',	'传真','邮箱'	,'上年销售额（万元）',
                                         '上年利润额（万元）','牵头单位性质','联合申报单位1名称',
                                         '单位性质','组织机构代码/三证合一码','联合申报单位2名称',
                                         '单位性质','组织机构代码/三证合一码','项目所在地','网址',
                                         '项目负责人','职务/职称','项目投资金额（万元）','目前已应用行业',
                                         '可应用推广行业','平台已注册用户总数','平台用户类型'	])
        self.now_row = 2

    def add_row(self, sheet_data):
        sheet_data=list(sheet_data)
        #print(sheet_data)
        self.worksheet1.write_row(f"A{self.now_row}", sheet_data)
        self.now_row += 1

    def save_xlsx(self):  # __del__处理的话self.f 已经被关掉了会报错
        print('文件处理完毕，正在导出.xlsx')
        self.f.close()
