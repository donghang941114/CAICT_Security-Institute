#批量doc2docx
import os
import time
from win32com.client import Dispatch
file_guanju=r'C:\code\word_excel3\extract_keyword_from_word2excel\docs_with_keyword'
files=os.listdir(file_guanju)
files.sort()
#print(files)
for i in range(len(files)):
    way=os.path.join(file_guanju,files[i])
    #print(way)
    for file_path in os.listdir(way):
        #print(file_path)
        file_name, file_extension = os.path.splitext(file_path)#获取文件名、文件扩展名
        #print(file_name,file_extension)
        if file_extension in [".doc"]:
            file_abs_path=os.path.join(way,file_path)
            #print(file_abs_path)
            #打开word应用程序
            wd=Dispatch("Word.application")
            # #后台运行
            # wd.Visible = 0
            # wd.DisplayAlerts = 0
            #打开doc文档,必须给一个绝对路径
            doc=wd.Documents.Open(file_abs_path)
            #另存为docx
            doc.SaveAs(file_abs_path+r"x",12)#12表示docx格式
            #关闭文档
            doc.Close()
            #退出word应用
            wd.Quit()
            #file_abs_path = file_abs_path+r"x"#更新路径为docx的路径
            os.remove(file_abs_path)
            time.sleep(0.5)
            print(way+file_path, '已转换完成')




# way = r'C:\code\word_excel3\extract_keyword_from_word2excel\docs_with_keyword\01北京管局'
# for file_path in os.listdir(way):
#     #print(file_path)
#     file_name, file_extension = os.path.splitext(file_path)#获取文件名、文件扩展名
#     #print(file_name,file_extension)
#     if file_extension in [".doc"]:
#         file_abs_path=os.path.join(way,file_path)
#         #print(file_abs_path)
#         #打开word应用程序
#         wd=Dispatch("Word.application")
#         # #后台运行
#         # wd.Visible = 0
#         # wd.DisplayAlerts = 0
#         #打开doc文档,必须给一个绝对路径
#         doc=wd.Documents.Open(file_abs_path)
#         #另存为docx
#         doc.SaveAs(file_abs_path+r"x",12)#12表示docx格式
#         #关闭文档
#         doc.Close()
#         #退出word应用
#         wd.Quit()
#         #file_abs_path = file_abs_path+r"x"#更新路径为docx的路径
#         os.remove(file_abs_path)
#         time.sleep(0.5)