#https://blog.51cto.com/357712148/2106106
from docx import Document
# #搜索并替换
# '''
# Args:
#     doc: 文档对象
#     old_text: 要被替换的文本
#     new_text: 要替换成的文本
# '''
# def replace_text(doc, old_text, new_text):
#     # 遍历每个段落
#     for p in doc.paragraphs:
#         # 如果要搜索的内容在该段落
#         if old_text in p.text:
#             # 使用 runs 替换内容但不改变样式
#             # 注意！runs 会根据样式分隔内容，确保被替换内容的样式一致
#             for run in p.runs:
#                 if old_text in run.text:
#                     run.text = run.text.replace(old_text, new_text)


# import os
# import docx
# from docx import Document #导入库
# from win32com.client import Dispatch
# from win32com import client as wc
#
# # path=r'C:\code\word_excel3\extract_keyword_from_word2excel\docs_with_keyword\01北京管局\4内网主机及容器资产安全隔离及精细化防护控制.docx'
# # document=Document(path)
# # for paragraph in document.paragraphs:
# #     print(paragraph.text)
# #
# # print(document.paragraphs[34].text)
# # print(document.paragraphs[35].text)
# # # for sections in document.sections:
# # #     print(sections)







# '''
# 获取绝对地址，如果是doc的转换为docx。
# '''
# way = r'C:\code\extract_keyword_from_word2excel\docs_with_keyword\11浙江管局' #r声明\不需要转义
# way=os.path.abspath(way) #相对转绝对
# for i in os.listdir(way):
#     if i.endswith('doc'):
#         path2=os.path.join(way,i)
#         os.chdir(way)
#         word = wc.Dispatch("Word.Application")
#         doc = word.Documents.Open(path2)
#         doc.SaveAs(path2+'x', 12)
#         doc.Close()
#         word.Quit()
#         os.remove(i)



# '''
# 读取word的表格内的数据，并按行打印。
# '''
# def read_word(way):
#     #way = r'C:\code\各省管局\广东管局\4基于零信任架构的网络安全接入管理平台.docx'
#     # for file_path in os.listdir(way):
#     #     #print(file_path)
#     #     file_name, file_extension = os.path.splitext(file_path)#获取文件名、文件扩展名
#     word = Document(way) #读入文件
#     tables=word.tables
#     #print(tables)
#     tb=tables[0]
#     #获取表格的行
#     tb_rows=tb.rows
#     #print(len(tb_rows))
#     tb_row_data=[]
#     for i in range(len(tb_rows)):
#         row_data = []
#         row_cells = tb_rows[i].cells
#         # 读取每一行单元格内容
#         for cell in row_cells:
#             row_data.append(cell.text)  # 单元格内容
#         #print(row_data)  # 打印整行数据
#         tb_row_data.append(row_data)
#     print(tb_row_data)
#     sheet_data=[]
#     sheet_data=tb_row_data[13][2],tb_row_data[1][1],tb_row_data[2][1],tb_row_data[2][3],\
#                tb_row_data[3][1],tb_row_data[3][3],tb_row_data[4][1],tb_row_data[4][3],\
#                tb_row_data[5][1],tb_row_data[5][3],tb_row_data[6][1],tb_row_data[6][3],\
#                tb_row_data[7][1],tb_row_data[9][1],tb_row_data[9][2],tb_row_data[9][3],\
#                tb_row_data[10][1],tb_row_data[10][2],tb_row_data[10][3],tb_row_data[14][1],\
#                tb_row_data[15][1],tb_row_data[16][1],tb_row_data[16][4],tb_row_data[17][1],\
#                tb_row_data[18][1],tb_row_data[19][1],tb_row_data[20][1],tb_row_data[20][4]
#     print(len(sheet_data))
#     print(type(sheet_data))
#     return sheet_data

#
# '''
# 往excel中填写数据，在读取word时把需要的数据存储下来，
# 在写入表格中的时候填入即可。
# '''
# # 导入模块
# from openpyxl import  Workbook
# from openpyxl import load_workbook
#
# def write_excel(sheet_data):
#     #新建excel
#     wb = Workbook() # 实例化
#     # 直接赋值可以改工作表的名称
#     sheet = wb.active
#     sheet.title = 'Sheet1'
#
#     #打开已有excel表格
#     # wb = load_workbook('../TEST.xlsx')
#     # #ws = wb["sheet1"]
#
#     # 给单元格赋值
#     sheet['A1'] = '项目名称';sheet['B1'] = '牵头申报单位';sheet['C1'] = '组织机构代码/三证合一码';
#     sheet['D1'] = '成立时间';sheet['E1'] = '通讯地址';sheet['F1'] = '注册资本（万元）'
#     sheet['G1'] = '联系人';sheet['H1'] = '联系电话';sheet['I1'] = '传真';sheet['J1'] = '邮箱'
#     sheet['K1'] = '上年销售额（万元）';sheet['L1'] = '上年利润额（万元）';sheet['M1'] = '单位性质'
#     sheet['N1'] = '联合申报单位1名称';sheet['O1'] = '单位性质';sheet['P1'] = '组织机构代码/三证合一码'
#     sheet['Q1'] = '联合申报单位2名称';sheet['R1'] = '单位性质';sheet['S1'] = '组织机构代码/三证合一码'
#     sheet['T1'] = '项目所在地';sheet['U1'] = '网址';sheet['V1'] = '项目负责人';
#     sheet['W1'] = '职务/职称';sheet['X1'] = '项目投资金额（万元）';sheet['Y1'] = '目前已应用行业'
#     sheet['Z1'] = '可应用推广行业';sheet['AA1'] = '平台已注册用户总数'
#     sheet['AB1'] = '平台用户类型'
#
#     sheet_data=list(list(sheet_data))
#     #print(sheet_data)
#     for item in [sheet_data]:
#         sheet.append(item)
#     # #通过行列定位
#     # sheet.cell(row=2, column=1).value = '你好'
#     # # 通过append方法
#     # sheet.append(['我是A1', '我是B1', '我是C1'])
#     # sheet.append(['我是A2', '我是B2', '我是C2'])
#     # 一次追加多行
#     # data_list = [
#     # ['1','2','3'],
#     # ['4','5','6'],
#     # ['7','8','9'],
#     # ]
#     # for item in data_list:
#     #     print(item)
#     #     sheet.append(item)
#     wb.save('../TEST.xlsx')
#     print('写入完成！')
#
# way = r'C:\code'
# #wb = Workbook() # 实例化
# # #打开已有excel表格
# # wb = load_workbook('../test汇总表.xlsx')
# # #ws = wb["Sheet1"]
# sheet_data_p=[]
# for file_name in os.listdir(way):
#     #print(file_name)
#     if file_name.endswith('docx') and not file_name.startswith('~$'):
#         deal_file=os.path.join(way,file_name)
#         #print(deal_file)
#         sheet_data=read_word(deal_file)
#         sheet_data_p.append(sheet_data)
# # print(sheet_data_p)
# sheet_data_p=[*sheet_data_p]
# # print(sheet_data_p)
# write_excel(sheet_data_p)
#     #write_excel(sheet_data)

# way = r'C:\code\word_excel3\extract_keyword_from_word2excel\docs_with_keyword\12安徽管局\1运营商级云网安全服务平台.docx'
# # for file_path in os.listdir(way):
# #     #print(file_path)
# #     file_name, file_extension = os.path.splitext(file_path)#获取文件名、文件扩展名
# word = Document(way)  # 读入文件
# tables = word.tables
# # print(tables)
# tb = tables[0]
# # 获取表格的行
# tb_rows = tb.rows
# # print(len(tb_rows))
# tb_row_data = []
# for i in range(len(tb_rows)):
#     row_data = []
#     row_cells = tb_rows[i].cells
#     # 读取每一行单元格内容
#     for cell in row_cells:
#         row_data.append(cell.text)  # 单元格内容
#     # print(row_data)  # 打印整行数据
#     tb_row_data.append(row_data)
# # print(len(tb_row_data))
# # print(tb_row_data)
# for i in range(len(tb_row_data)):
#     tb_row_data[i]=sorted(set(tb_row_data[i]), key=tb_row_data[i].index)
# for i in range(len(tb_row_data)):
#     while len(tb_row_data[i])<4:
#         tb_row_data[i].append('/')
# # if len(tb_row_data[0])==4:
# #     for i in range(len(tb_row_data)):
# #         tb_row_data[i].append(tb_row_data[i][3])
# if '联合申报单位' not in tb_row_data[9][0]:
#     tb_row_data.insert(9,['联合申报单位','/','/','/'])
# if '联合申报单位' not in tb_row_data[10][0]:
#     tb_row_data.insert(10, ['联合申报单位', '/', '/', '/'])
# #标准化补齐’/‘
# for i in range(len(tb_row_data)):
#     j=0
#     for item in tb_row_data[i]:
#         j+=1
#         if item =='':
#             tb_row_data[i][j - 1]='/'
# print(len(tb_row_data))
# print(tb_row_data)

##统一时间格式
def str2date(str_date):
    str_date = str_date.strip()
    year = 1900
    month = 1
    day = 1
    if (len(str_date) > 11):
        str_date = str_date[:11]
    if (str_date.find('-') > 0):
        year = str_date[:4]
        if (year.isdigit()):
            year = int(year)
        else:
            year = 0
        month = str_date[5:str_date.rfind('-')]
        if (month.isdigit()):
            month = int(month)
        else:
            month = 0
        if (str_date.find(' ') == -1):
            day = str_date[str_date.rfind('-') + 1:]
        else:
            day = str_date[str_date.rfind('-') + 1:str_date.find(' ')]
        if (day.isdigit()):
            day = int(day)
        else:
            day = 0
    elif (str_date.find('年') > 0):
        year = str_date[:4]
        if (year.isdigit()):
            year = int(year)
        else:
            year = 0
        month = str_date[5:str_date.rfind('月')]
        if (month.isdigit()):
            month = int(month)
        else:
            month = 0
        #print(str_date.rfind('月'))
        if str_date.rfind(('月')):
            day = str_date[str_date.rfind('月') + 1:str_date.rfind('日')]
            if (day.isdigit()):
                day = int(day)
            else:
                day = 0
        if str_date.rfind(('月'))==-1:
            day=0
    elif (str_date.find('/') > 0):
        year = str_date[:4]
        if (year.isdigit()):
            year = int(year)
        else:
            year = 0
        month = str_date[5:str_date.rfind('/')]
        if (month.isdigit()):
            month = int(month)
        else:
            month = 0
        if (str_date.find(' ') == -1):
            day = str_date[str_date.rfind('/') + 1:]
        else:
            day = str_date[str_date.rfind('/') + 1:str_date.find(' ')]
        if (day.isdigit()):
            day = int(day)
        else:
            day = 0
    elif (str_date.find('.')>0):
        year = str_date[:4]
        if (year.isdigit()):
            year = int(year)
        else:
            year = 0
        month = str_date[5:str_date.rfind('.')]
        if (month.isdigit()):
            month = int(month)
        else:
            month = 0
        if (str_date.find(' ') == -1):
            day = str_date[str_date.rfind('.') + 1:]
        else:
            day = str_date[str_date.rfind('.') + 1:str_date.find(' ')]
        if (day.isdigit()):
            day = int(day)
        else:
            day = 0
    elif str_date.isdigit():
        year=str_date
        month=0
        day=0
    else:
        year = 8888
        month = 88
        day = 88
    if month < 10:
        month = '0' + str(month)
    if day < 10:
        day = '0' + str(day)
    return '%s年%s月%s日' % (year, month, day)
print(str2date('2008'))




