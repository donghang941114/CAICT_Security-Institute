
import os
import xlwt

from docx import Document #导入库

filepath='../内蒙古'
dirs = os.listdir(filepath)
workbook = xlwt.Workbook(encoding='ascii')
worksheet = workbook.add_sheet('My Worksheet')
worksheet.write(0,0,'姓名')
worksheet.write(0,1,'生日')
worksheet.write(0,2,'身份证号')
i=1
for file in dirs:

    document = Document(filepath+'/'+file)  # 读入文件
    tables = document.tables  # 获取文件中的表格集
    table = tables[0]  # 获取文件中的第一个表格
    name=table.cell(0,3).text
    birthday=table.cell(0,20).text
    idnumber=table.cell(1,20).text
    print(name+" "+birthday+" "+idnumber)
    worksheet.write(i,0,name)
    worksheet.write(i, 1, birthday)
    worksheet.write(i, 2, idnumber)

    i=i+1

workbook.save('校友信息汇总表.xls')
